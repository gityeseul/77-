package com.chill.domain;

public class CrawVO {
	String item_name;
	String item_color;
	String item_image;
	String item_content;
	String item_size;
	int item_price;
	int item_count;
	String store_name;
	String store_url;
	String name_url;
	String price_url;
	String content_url;
	String img_url;
	String color_url;
	String size_url;
	String temp1_url;
	String temp2_url;
	String temp3_url;
	
	
	public String getName_url() {
		return name_url;
	}
	public void setName_url(String name_url) {
		this.name_url = name_url;
	}
	public String getPrice_url() {
		return price_url;
	}
	public void setPrice_url(String price_url) {
		this.price_url = price_url;
	}
	public String getContent_url() {
		return content_url;
	}
	public void setContent_url(String content_url) {
		this.content_url = content_url;
	}
	public String getImg_url() {
		return img_url;
	}
	public void setImg_url(String img_url) {
		this.img_url = img_url;
	}
	public String getColor_url() {
		return color_url;
	}
	public void setColor_url(String color_url) {
		this.color_url = color_url;
	}
	public String getSize_url() {
		return size_url;
	}
	public void setSize_url(String size_url) {
		this.size_url = size_url;
	}
	public String getTemp1_url() {
		return temp1_url;
	}
	public void setTemp1_url(String temp1_url) {
		this.temp1_url = temp1_url;
	}
	public String getTemp2_url() {
		return temp2_url;
	}
	public void setTemp2_url(String temp2_url) {
		this.temp2_url = temp2_url;
	}
	public String getTemp3_url() {
		return temp3_url;
	}
	public void setTemp3_url(String temp3_url) {
		this.temp3_url = temp3_url;
	}
	public String getStore_url() {
		return store_url;
	}
	public void setStore_url(String store_url) {
		this.store_url = store_url;
	}
	public String getStore_name() {
		return store_name;
	}
	public void setStore_name(String store_name) {
		this.store_name = store_name;
	}
	public int getItem_count() {
		return item_count;
	}
	public void setItem_count(int item_count) {
		this.item_count = item_count;
	}
	public String getItem_size() {
		return item_size;
	}
	public void setItem_size(String item_size) {
		this.item_size = item_size;
	}

	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getItem_color() {
		return item_color;
	}
	public void setItem_color(String item_color) {
		this.item_color = item_color;
	}
	public String getItem_image() {
		return item_image;
	}
	public void setItem_image(String item_image) {
		this.item_image = item_image;
	}
	public String getItem_content() {
		return item_content;
	}
	public void setItem_content(String item_content) {
		this.item_content = item_content;
	}

	public int getItem_price() {
		return item_price;
	}
	public void setItem_price(int item_price) {
		this.item_price = item_price;
	}
	
}
