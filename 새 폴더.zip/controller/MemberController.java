package com.chill.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.chill.domain.BoaberVO;
import com.chill.domain.MemberVO;
import com.chill.service.BoardServiceImpl;
import com.chill.service.MemberService;
import com.chill.service.MemberServiceImpl;

@Controller
public class MemberController {

	private static final Logger logger = (Logger) LogManager.getLogger("");
	
	@RequestMapping("{url}.do")
	public String regist(@PathVariable String url,HttpSession session) {
		//로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : url");
	      }
		return "/user/" + url;
	} // webapp/resources/cozastore-master + user/userJoin +url + .jsp

	@Autowired
	private MemberServiceImpl memberService;
	
	@Autowired
	private BoardServiceImpl boardService;
	
	@RequestMapping("JoinForm")
	public String join(HttpSession session) {
		//로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : JoinForm");
	      }
		return "/user/JoinForm";
	}
	@RequestMapping("mypage")
	public String mypage(HttpSession session) {
		//로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : mypage");
	      }
		System.out.println("...");
		return "/user/mypage";
	}
	@RequestMapping("myprofile")
	public String my(HttpSession session) {
		//로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : myprofile");
	      }
		return "/user/myprofile";
	}
	
	@RequestMapping("/myboard.do")
	public String getMyBoardList(BoaberVO vo, Model model, HttpSession session) {	
		System.out.println("*************************************");
		MemberVO temp= new MemberVO();
		temp =  (MemberVO) session.getAttribute("vo");
		vo.setCnum(temp.getCnum());
		System.out.println("cnum: "+vo.getCnum());
		List<BoaberVO> list = boardService.getMyBoardList(vo);
		System.out.println(list);
		model.addAttribute("boardList2", list);
		//로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : myboard");
	      }
		return "/user/myboard";
	}

	@ResponseBody // ********** 비동기통신
	@RequestMapping(value = "/idCheck.do", produces = "application/text;charset=UTF-8")
	public String idcheck(MemberVO vo,HttpSession session) {
		MemberVO result = memberService.idCheck_Login(vo);
		String message = "ID 사용가능합니다";
		if (result != null)
			message = "중복된 ID가 있습니다";
		//로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : idCheck");
	      }
		return message;
	}
	/*
	 * Spring에서 String을 리턴하면 뷰페이지 지정이 되어버림 무조건 뷰페이지 지정되어서 화면이 변경됨 (페이지 전환됨)
	 */

	@RequestMapping(value = "/login.do")
	public String login(MemberVO vo, HttpSession session) {
		MemberVO result = memberService.idCheck_Login(vo);

		if (result == null || result.getId() == null) {
			return "/MainChill";
		} else {
			session.setAttribute("vo", result);
		}
		//로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : login");
	      }
		return "redirect:MainChill.do";

	}

	@RequestMapping(value = "/logout.do")
	public String logout(MemberVO vo, HttpSession session) {
		session.removeAttribute("vo");
		//로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : logout");
	      }
		return "redirect:MainChill.do";

	}
	
	@RequestMapping("/userInsert.do")
	public ModelAndView insert(MemberVO vo,HttpSession session) {
		int result = memberService.userInsert(vo);
		String message = "가입되지 않았습니다";
		if (result == 1)
			message = vo.getName() + "님 가입 성공";

		ModelAndView mv = new ModelAndView();
		mv.setViewName("user/userJoin_ok");
		mv.addObject("message", message);
		mv.addObject("result", result);
		//로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : userInsert");
	      }
		return mv;
	}

	  @RequestMapping("/update_mypage.do")
			public ModelAndView update_mypage(MemberVO vo,HttpSession session) {
		  System.out.println("update_mypage:"+vo.getId());
		  int result = memberService.update_mypage(vo);
			String message = "가입되지 않았습니다";
			if (result == 1)
				message = vo.getName() + "님 가입 성공";

			ModelAndView mv = new ModelAndView();
			mv.setViewName("user/userJoin_ok");
			mv.addObject("message", message);
			mv.addObject("result", result);
			//로그를 위한 것
		      MemberVO user = (MemberVO)session.getAttribute("vo");
		      if(user!=null) {
		    	  logger.info("user : "+user.getName()+"\t page : update_mypage");
		      }
			return mv;
			}
		   
	  
}
