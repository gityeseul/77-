package com.chill.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.chill.service.BoardService;
import com.chill.domain.BoaberVO;
import com.chill.domain.BoardVO;
import com.chill.domain.MemberVO;

@Controller
@RequestMapping("/board")
public class BoardController {
   
   @Autowired
   private BoardService boardService;

      //
      @RequestMapping("/{step}.do")
      public String viewPage(@PathVariable String step) {
         return "/board/"+step;
      }
   
      // 글 목록 검색
//      @RequestMapping("/getBoardList.do")
//      public void getBoardList(BoardVO vo, Model model) {         
//         model.addAttribute("boardList", boardService.getBoardList(vo));
//         // ViewResolver를 지정하지 않으면 아래처럼 페이지명 지정
////          return "views/getBoardList.jsp"; // View 이름 리턴
//         
//      }
      
      // 글 목록 페이징
      @RequestMapping("/getBoardList.do")
      public void Pagelist(Model model, BoardVO vo,@RequestParam(value="pageno", required = false) int pageno) {

         int startlist = pageno*10-9;
         int lastlist = startlist+9;         
         BoardVO bvo = new BoardVO();
         bvo.setStartlist(startlist);
         bvo.setLastlist(lastlist);         

         List<BoardVO> listpage = boardService.Pagelist(bvo);
         System.out.println("list:"+listpage);
         int amountlist = listpage.size();   //전체게시글수   10   
         int amountpage = amountlist/10+pageno;   //이건 페이지수 2
         System.out.println("ami:"+amountpage);   
         model.addAttribute("listPage", listpage);
         model.addAttribute("amountlist", amountlist); //10
         model.addAttribute("amountpage", amountpage); //2
      }
   
      // 글 등록
      @RequestMapping("/saveBoard.do")
      public String insertBoard(BoardVO vo) throws Exception {      
         boardService.insertBoard(vo);
         return "redirect:/board/getBoardList.do?pageno=1";
      }

      // 글 수정
      @RequestMapping("/updateBoard.do")
      public String updateBoard(BoardVO vo)  {
         boardService.updateBoard(vo);
         return "redirect:/board/getBoardList.do?pageno=1";
      }

      // 글 삭제
      @RequestMapping("/deleteBoard.do")
      public String deleteBoard(BoardVO vo) {
         boardService.deleteBoard(vo);
         return "redirect:/board/getBoardList.do?pageno=1";
      }

      // 글 상세 조회
      @RequestMapping("/getBoard.do")
      public void getBoard(BoardVO vo, Model model) {
         model.addAttribute("board", boardService.getBoard(vo)); // Model 정보 저장         
      }
      @RequestMapping("/myboard.do")
      public void getMyBoardList(BoaberVO vo, Model model, HttpSession session) {   
         System.out.println("*************************************");
         MemberVO temp= new MemberVO();
         temp =  (MemberVO) session.getAttribute("vo");
         vo.setCnum(temp.getCnum());      
         model.addAttribute("boardList2", boardService.getMyBoardList(vo));
      }
}