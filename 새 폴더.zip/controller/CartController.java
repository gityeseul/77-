package com.chill.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chill.service.CartService;
import com.chill.service.CartServiceImpl;
import com.chill.service.Crawling_Serivce;
import com.chill.domain.CrawVO;
import com.chill.domain.MemberVO;
import com.chill.domain.CartVO;

@Controller
public class CartController {
	
	private static final Logger logger = (Logger) LogManager.getLogger("");
	 
	@Autowired
	private CartServiceImpl cartService;
	
	@Autowired
	private Crawling_Serivce srv;
//		@RequestMapping("/{step}.do")
//		public String viewPage(@PathVariable String step) {
//		return step;
//		}
	
		@RequestMapping(value="/insertCart.do",method = RequestMethod.POST)
		@ResponseBody
		public void insertCart(@RequestParam Map<String, Object> map,HttpServletRequest request,HttpSession session) {
			String str = String.valueOf(map.get("num"));
			int num = Integer.parseInt(str);
			CrawVO vo = new CrawVO();
			vo=srv.selectByNum(num);
			System.out.println(vo.getItem_size());
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("cnum",session.getAttribute("vo"));
			param.put("vo",vo);
			cartService.insertCart(param);	
			
			//로그를 위한 것
			MemberVO user = (MemberVO)session.getAttribute("vo");
				if(user!=null) {
					logger.info("user : "+user.getName()+"\t page : insertCart");
				}
		}

		@RequestMapping("/shoping-cart.do")
		public void getCartList(CartVO vo,HttpSession session, Model model) {
			MemberVO temp = new MemberVO();
			temp = (MemberVO)session.getAttribute("vo");
			vo.setCnum(temp.getCnum());
			System.out.println(vo.getCnum());
			model.addAttribute("CartList", cartService.getCartList(vo));  

			//로그를 위한 것
		      MemberVO user = (MemberVO)session.getAttribute("vo");
		      if(user!=null) {
		    	  logger.info("user : "+user.getName()+"\t page : shoping-cart");
		      }
		}
		@RequestMapping(value="/showCart.do")
		@ResponseBody
		public List<CartVO> showCart(CartVO vo,HttpSession session,HttpServletRequest request) {
			MemberVO temp=new MemberVO();
			temp=(MemberVO) session.getAttribute("vo");
			vo.setCnum(temp.getCnum());
			
			//로그를 위한 것
		      MemberVO user = (MemberVO)session.getAttribute("vo");
		      if(user!=null) {
		    	  logger.info("user : "+user.getName()+"\t page : showCart");
		      }
			return cartService.getCartList(vo);
			
		}

		
		@RequestMapping("/deleteCart.do")
		@ResponseBody
		public void deleteCart(HttpServletRequest request,HttpSession session){
			String []str = request.getParameterValues("num[]");
			for(String i : str) {
				int num = Integer.parseInt(i);
				cartService.deleteCart(num);
			}
			
			//로그를 위한 것
		      MemberVO user = (MemberVO)session.getAttribute("vo");
		      if(user!=null) {
		    	  logger.info("user : "+user.getName()+"\t page : deleteCart");
		      }
		}
		@RequestMapping("/yabal.do")
		public String yabal(HttpSession session,CartVO vo) {
			MemberVO temp = new MemberVO();
			temp = (MemberVO)session.getAttribute("vo");
			vo.setCnum(temp.getCnum());
			System.out.println(vo.getCnum());
			List<CartVO> list = cartService.getCartList(vo);
			for(CartVO i : list) {
				i.setCnum(temp.getCnum());
				cartService.yabal(i);
				cartService.deleteCart(i.getCart_num());
				cartService.updateCart(i.getItem_index());
			}
			
			//로그를 위한 것
		      MemberVO user = (MemberVO)session.getAttribute("vo");
		      if(user!=null) {
		    	  logger.info("user : "+user.getName()+"\t page : yabal");
		      }
			return "redirect:mypage.do";
		}


	}
