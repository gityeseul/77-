package com.chill.controller;


import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.chill.domain.CrawVO;
import com.chill.domain.MemberVO;
import com.chill.service.Crawling_Serivce;

@Controller
public class Crawling_Controller {
	
	private static final Logger logger = (Logger) LogManager.getLogger("");



	
	@Autowired
	private Crawling_Serivce srv;

	
	@RequestMapping("/topList.do")
	public String crawlingTopList(HttpServletRequest requst,Model model,HttpSession session) {
		CrawVO vo = new CrawVO();
		vo.setCategory_num(Integer.parseInt(requst.getParameter("category_num")));
		model.addAttribute("toplist",srv.CrawlingTopList(vo));
	    //로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : topList");
	      }
		return "01top";
	}
	@RequestMapping("/bottomList.do")
	public String crawlingbottomList(HttpServletRequest requst,Model model,HttpSession session) {
		CrawVO vo = new CrawVO();
		vo.setCategory_num(Integer.parseInt(requst.getParameter("category_num")));
		model.addAttribute("bottomlist",srv.CrawlingTopList(vo));
	    //로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : bottomList");
	      }
		return "02_bottom";
	}
	@RequestMapping("/dressList.do")
	public String crawlingdressList(HttpServletRequest requst,Model model,HttpSession session) {
		CrawVO vo = new CrawVO();
		vo.setCategory_num(Integer.parseInt(requst.getParameter("category_num")));
		model.addAttribute("dresslist",srv.CrawlingTopList(vo));
	    //로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : dressList");
	      }
		return "03_dress";
	}
	@RequestMapping("/accList.do")
	public String crawlingaccList(HttpServletRequest requst,Model model,HttpSession session) {
		CrawVO vo = new CrawVO();
		vo.setCategory_num(Integer.parseInt(requst.getParameter("category_num")));
		model.addAttribute("acclist",srv.CrawlingTopList(vo));
	    //로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : accList");
	      }
		return "04_acc";
	}

	@RequestMapping(value="/MainChill.do")
	   public void mainpage(CrawVO vo,Model model,HttpSession session) {
	      model.addAttribute("selectitem",srv.selectitem(vo));
	      model.addAttribute("bestseller",srv.bestseller(vo));
	      
	      //로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : MainChill");

	      }



	}

	@RequestMapping(value="/product-detail.do")
	public void product_detail(int num,Model model,HttpSession session) {
		model.addAttribute("item", srv.selectByNum(num));
		//로그를 위한 것
		MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : product-detail");
	      }
	}
	// 상품 검색 
	   @RequestMapping(value="SearchPage.do")
	   public String searchList(String keyword, Model model,HttpSession session) {      
	      model.addAttribute("searchList", srv.searchList(keyword));
	    //로그를 위한 것
	      MemberVO user = (MemberVO)session.getAttribute("vo");
	      if(user!=null) {
	    	  logger.info("user : "+user.getName()+"\t page : SearchPage");
	      }
	      return "SearchPage";
	   }
}
