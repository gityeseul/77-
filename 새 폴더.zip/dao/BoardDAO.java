package com.chill.dao;

import java.util.List;

import com.chill.domain.BoaberVO;
import com.chill.domain.BoardVO;

public interface BoardDAO {
	public void insertBoard(BoardVO vo);

	public void updateBoard(BoardVO vo) ;

	public void deleteBoard(BoardVO vo);

	public BoardVO getBoard(BoardVO vo) ;

	public List<BoardVO> getBoardList(BoardVO vo) ;
	
	public List<BoaberVO> getMyBoardList(BoaberVO vo) ;
	// 페이징
		public List<BoardVO> Pagelist(BoardVO vo);
}
