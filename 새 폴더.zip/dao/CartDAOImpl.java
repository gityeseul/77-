package com.chill.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.chill.domain.CartVO;
import com.chill.domain.CrawVO;



@Repository("CartDAO") 
public class CartDAOImpl implements CartDAO{
	@Autowired
	private SqlSessionTemplate mybatis;

	public void insertCart(Map<String, Object> map) {
		System.out.println("===> Mybatis insertCart() 호출");
		mybatis.insert("CartDAO.insertCart", map);
	}

	public void updateCart(int num) {
		System.out.println("===> Mybatis updateCart() 호출");
		mybatis.update("CartDAO.updateCart", num);
	}

	public void deleteCart(int num) {
		System.out.println("===> Mybatis deleteCart() 호출");
		mybatis.delete("CartDAO.deleteCart", num);
	}
	
	public List<CartVO> getCartList(CartVO vo) {
		System.out.println("===> Mybatis getCartList() 호출");
		return mybatis.selectList("CartDAO.getCartList", vo);
	}
	public void yabal(CartVO vo) {
		System.out.println("===> Mybatis 야발 호출");
		mybatis.insert("CartDAO.insertBuy", vo);
	}
}