package com.chill.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.chill.domain.*;

@Repository
public class Crawling_Dao {

	@Autowired
	private SqlSessionTemplate mybatis;
	
	public CrawVO selectByNum(int num) {
		return mybatis.selectOne("CrawlingDao.selectByNum",num);
	}
	
	public List<CrawVO> CrawlingTopList(CrawVO vo){
		return mybatis.selectList("CrawlingDao.CrawlingTopList",vo);
	}
	public List<CrawVO> topListByCnt(Map<String, Object> param){
		return mybatis.selectList("CrawlingDao.topListByCnt", param);
	}
	
	public List<CrawVO> bottomlist(CrawVO vo){
		return mybatis.selectList("CrawlingDao.bottomlist");
	}
	public List<CrawVO> selectitem(CrawVO vo){
	      return mybatis.selectList("CrawlingDao.selectitem");
	}
	public List<CrawVO> bestseller(CrawVO vo){
	      return mybatis.selectList("CrawlingDao.bestseller");
	}
	// 상품 검색

   public List<CrawVO> searchList(String keyword) {
	      System.out.println("=====> Mybatis SearchList() 호출");
	      return mybatis.selectList("CrawlingDao.searchList", keyword);
	   }
	
}
