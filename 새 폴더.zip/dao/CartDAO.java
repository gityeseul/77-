package com.chill.dao;

import java.util.List;
import java.util.Map;

import com.chill.domain.CartVO;

public interface CartDAO {
	
	public void insertCart(Map<String, Object> map);
	
	public void updateCart(int num) ;
	
	public void deleteCart(int num);

	public List<CartVO> getCartList(CartVO vo) ;
	public void yabal(CartVO vo);
}
