package com.chill.service;

import java.util.List;
import java.util.Map;

import com.chill.domain.CartVO;
import com.chill.domain.CrawVO;

public interface CartService {
	// 장바구니 가지고 오기
	void insertCart(Map<String, Object> map);
	// 장바구니 수정하기
	void updateCart(int num);
	// 장바구니 삭제
	void deleteCart(int num);

	// 장바구니 조회s
	static List<CartVO> getCartList(CartVO vo) {
		// TODO Auto-generated method stub
		return null;
	}
	void yabal(CartVO vo);
}
