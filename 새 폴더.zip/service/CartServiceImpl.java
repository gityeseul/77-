package com.chill.service;
/*BoardController.javapackage com.chilllli.Service;*/
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chill.dao.CartDAOImpl;
import com.chill.domain.CartVO;
import com.chill.domain.CrawVO;


@Service("CartService")
public class CartServiceImpl implements CartService {
	@Autowired
	private CartDAOImpl CartDAO;
	
	public void insertCart(Map<String, Object> map) {
		 CartDAO.insertCart(map);
	}
	public void updateCart(int num) {
		CartDAO.updateCart(num);
	}
	public void deleteCart(int num) {
		CartDAO.deleteCart(num);
	}
	
	public List<CartVO> getCartList(CartVO vo) {
		return CartDAO.getCartList(vo);
	}
	public void yabal(CartVO vo) {
		CartDAO.yabal(vo);
	}
	
	
}