package com.chill.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chill.dao.Crawling_Dao;
import com.chill.domain.CrawVO;

@Service
public class Crawling_Serivce {
	
	@Autowired
	private Crawling_Dao dao;
	
	public CrawVO selectByNum(int num) {
		CrawVO vo = dao.selectByNum(num);
		String temp = Integer.toString(vo.getItem_price());
		int len = temp.length();
		vo.setPriceView(temp.substring(len-len,len-3)+","+temp.substring(len-3,len)+"원");
		return vo;
	}
	public List<CrawVO> CrawlingTopList(CrawVO vo){
		List<CrawVO> list = dao.CrawlingTopList(vo);
		List<CrawVO> result= new ArrayList<CrawVO>();
		for(CrawVO cv : list) {
			String temp = Integer.toString(cv.getItem_price());
			int len = temp.length();
			cv.setPriceView(temp.substring(len-len,len-3)+","+temp.substring(len-3,len)+"원");
			result.add(cv);
		}
		return result;
	}
	
	public List<CrawVO> topListByCnt(Map<String, Object> param){
		List<CrawVO> list = dao.topListByCnt(param);
		List<CrawVO> result= new ArrayList<CrawVO>();
		for(CrawVO cv : list) {
			String temp = Integer.toString(cv.getItem_price());
			int len = temp.length();
			cv.setPriceView(temp.substring(len-len,len-3)+","+temp.substring(len-3,len)+"원");
			result.add(cv);
		}
		return result;
	}
	
	
	public List<CrawVO> bottomlist(CrawVO vo){
		List<CrawVO> list = dao.bottomlist(vo);
		List<CrawVO> result= new ArrayList<CrawVO>();
		for(CrawVO cv : list) {
			String temp = Integer.toString(cv.getItem_price());
			int len = temp.length();
			cv.setPriceView(temp.substring(len-len,len-3)+","+temp.substring(len-3,len)+"원");
			result.add(cv);
		}
		return result;
	}
	public List<CrawVO> selectitem(CrawVO vo){
	      return dao.selectitem(vo);
	}
	public List<CrawVO> bestseller(CrawVO vo){
	      return dao.bestseller(vo);
	}
	// 상품 검색
    public List<CrawVO> searchList(String keyword){
        List<CrawVO> list = dao.searchList(keyword);
        return list;      
     
   }
}
